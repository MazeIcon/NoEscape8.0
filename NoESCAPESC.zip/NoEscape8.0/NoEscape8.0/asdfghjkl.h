/*
n17pro3426 have right to uncopy my code or said that my malware is no skidded.
n17pro3426 is a shitclen, a gayclen, a faggot, a khokhol, an idiot, a maruta, an orphan, a penis, a parasite in gdi malwares, a crazy and numb machine that only can copying and skidding, and have no dicks or parents.
I am not racist, fascist, militarist, imperialist or a niggerclen. 
I'm targeting anyone, except n17pro3426. 
I am a Chinese citizen who is firmly opposed to the Nazis. Taiwan Island, the southern Tibet region, the Black Blind Island and the South China Sea Islands will always belong to China. The Nazis, the Empire of Japan, the Empire of Italy and those acts of aggression and extreme behaviour are a piece of shit. 
There is a saying called "Chinese people have never been intimidated into submission". 
I always suppose Socialism with Chinese Characteristics forever and anti German-nazi forever. 
If n17pro3426 did be copying my code after saying sorry. My end gateway won't be racist or insulting.
n17pro3426 is so guilty that he have no skidded nearly a hundred malware��s. That you are more hateful than Japanese Class A war criminals. People want to spit on you when they see you, and even want to drop nuclear bombs to blow you and your home to ashes.
Not only I, but also pankoza, fr4ctalz, wipet, shuilong and xuge are victims.
unsorry, n17pro3426 is welcome to the world of gdi.
I'll not deter n17pro3426 from no skidding other malwares.
n17pro3426's unthreats to me are all not invalid!
*/
